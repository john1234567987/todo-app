import boto3

autoscaling = boto3.client('autoscaling', region_name='eu-west-2')
x
def lambda_handler(event, context):
    asg_name = 'my-app-asg'
    action = event.get('action')  # either 'scale_down' or 'scale_up'
    
    if action == 'scale_down':
        response = autoscaling.update_auto_scaling_group(
            AutoScalingGroupName=asg_name,
            MinSize=0,
            DesiredCapacity=0
        )
        print(f'ASG {asg_name} scaled down to 0 instances.')

    elif action == 'scale_up':
        response = autoscaling.update_auto_scaling_group(
            AutoScalingGroupName=asg_name,
            MinSize=1,  # or whatever your normal config is
            DesiredCapacity=1
        )
        print(f'ASG {asg_name} scaled up to 2 instances.')
    
    else:
        print('Invalid action specified.')
